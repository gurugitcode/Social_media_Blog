"""SmarThinks_Blogs URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path('admin/', admin.site.urls),
    path('home/',include('BIS_Thinks.urls')),
    path('Profile',include('BIS_Thinks.urls')),
    path('CREATEUSER',include('BIS_Thinks.urls')),
    path('login/',include('BIS_Thinks.urls')),
    path('user1/',include('BIS_Thinks.urls')),
    path('add/',include('BIS_Thinks.urls')),
    path('board/',include('BIS_Thinks.urls')),
    path('image/',include('BIS_Thinks.urls')),
    path('imag/',include('BIS_Thinks.urls')),
    path('video/',include('BIS_Thinks.urls')),
    path('del_post/',include('BIS_Thinks.urls')),
    path('del_img/',include('BIS_Thinks.urls')),
    path('del_video/',include('BIS_Thinks.urls')),
    path('del_chat/',include('BIS_Thinks.urls')),
    path('updatepost/',include('BIS_Thinks.urls')),
    path('updateimg/',include('BIS_Thinks.urls')),
    path('pro/',include('BIS_Thinks.urls')),
    path('chat/',include('BIS_Thinks.urls')),
    path('PROFILE/',include('BIS_Thinks.urls')),
    path('imformation/',include('BIS_Thinks.urls')),
    path('galeryes/',include('BIS_Thinks.urls')),
   
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root= settings.MEDIA_ROOT)

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,
                          document_root=settings.MEDIA_ROOT)

     