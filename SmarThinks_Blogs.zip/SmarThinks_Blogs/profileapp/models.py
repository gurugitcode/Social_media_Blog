from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MaxValueValidator
# Create your models here.
class UserProfile(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE,primary_key=True)
    bio = models.CharField(max_length=200,default='Bio..')
    pro_image = models.ImageField(upload_to='images',default='Uplode image')
    def __str__(self):
        return self.bio

class UserPersionalData(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE,primary_key=True)
    mobailno = models.IntegerField(default='+91',validators=[MaxValueValidator(9999999999)])
    website =models.CharField(max_length=70,default='website')
    gender =models.CharField(max_length=70,default='gender')
    dob =models.DateField(default='DOB')
    
