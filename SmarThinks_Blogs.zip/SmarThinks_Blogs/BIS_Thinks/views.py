from django.shortcuts import render,HttpResponseRedirect
from django.views import View
from django.contrib.auth.models import User, Group
from django.contrib.auth.forms import PasswordResetForm
from .forms import SignUpForm ,LoginForm , Form_Bloger_data,ImageForm,VideoForm,EditUserProfileForm,Chat_form,Usercontectform,Userprofileform
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout
from .models import Bloger_data,Model_Image,ModelUpVideo,DATA_chat
from django.contrib.auth.decorators import login_required
from profileapp.models import UserProfile,UserPersionalData

# from django.views.generic.list import ListView
# Create your views here.
def ProfilePage(request):
    if request.user.is_authenticated:
        if request.method == 'POST':
                fm=EditUserProfileForm(request.POST,instance=request.user)
                if fm.is_valid():
                    messages.success(request,'Edit profile SUCCESSFULY')
                    fm.save()
                    user=request.user
                    post_data = UserProfile.objects.values_list()
                    return render(request,'blogs/prfile.html',{'form':fm,'img':post_data})
                    
        else:
            fm = EditUserProfileForm(instance=request.user)
            user=request.user
            post_data = UserProfile.objects.filter(user= user )
            return render(request,'blogs/prfile.html',{'form':fm,'img':post_data})
            
        return render(request,'blogs/prfile.html',{'name':request.user,'form':fm})
    else:
        return HttpResponseRedirect('/login/user')

class HomePage(View):
    templates_name='blogs/home.html'
    def get(self,request):
        if request.user.is_authenticated:
            list1=[]
            fm = Bloger_data.objects.order_by("?" )
            list1.append(fm)
            # instance = User.objects.values_list('username')
            post_data = UserProfile.objects.all()
        
            for i in list1:
                data=i
            return render(request,self.templates_name,{'form':i})
        else:
            return HttpResponseRedirect('/login/user')    
# def home(request):
#     return render(request,'blogs/home.html')

class User_Create(View):
    template_name = 'blogs/usersingup.html'
    def get(self,request):
        fm_data = SignUpForm()
        return render(request,self.template_name,{"form":fm_data})

    def post(self,request):
        if request.method =='POST':
            fm_data = SignUpForm(request.POST)
            if fm_data.is_valid():
                messages.success(request,'Congratulations You have become authot')
                user=fm_data.save()
                group = Group.objects.get(name='Author')
                user.groups.add(group)
                fm_data =SignUpForm()
        else:
            fm_data =SignUpForm()
        return render(request,self.template_name,{"form":fm_data})           

def  UserLogin(request):
        if request.method =='POST':
            fm = LoginForm(request=request,data=request.POST)
            if fm.is_valid():
                uname = fm.cleaned_data['username']
                upass = fm.cleaned_data['password']
                user = authenticate(username=uname,password=upass)
                if user is not None:
                    login(request,user)
                    group = Group.objects.get(name='Author')
                    users = group.user_set.all()
                    messages.success(request,'Login in Successfuly')
                    return HttpResponseRedirect('/home/home')
        else:
            fm=LoginForm()
        return render(request,'blogs/Login.html',{'form':fm})
  
class Add_Post(View):
    template_name = 'blogs/adddata.html'
    def get(self,request):
        if request.user.is_authenticated:
            fm = Form_Bloger_data()
            return render(request,self.template_name,{'form':fm})
        else:
            return HttpResponseRedirect('/login/user')
    def post(self,request):
        if request.user.is_authenticated:
            fm = Form_Bloger_data(request.POST)
            if fm.is_valid():
                user = request.user
                tit = fm.cleaned_data['title']
                des = fm.cleaned_data['desc']
                rec = Bloger_data(user=user,title=tit,desc=des)
                rec.save()
                messages.success(request,'Successfully Your Post uploded.')
                fm = Form_Bloger_data()
                return render(request,self.template_name,{'form':fm})
        else:
            return HttpResponseRedirect('/login/user')
class DeshBoard(View):
    template_name = 'blogs/Deshboard.html'
    def get(self,request):
        if request.user.is_authenticated:
            user = request.user
            post_data = Bloger_data.objects.filter(user= user )
            data1 =Model_Image.objects.filter(user= user )
            videdata =ModelUpVideo.objects.filter(user= user )
            return render(request,self.template_name,{'data':post_data,'image_date':data1,'videodata':videdata})
        else:
            return HttpResponseRedirect('/login/user')
class Update_post(View):
    template_name = 'blogs/update.html'
    def get(self,request,id):
        if request.user.is_authenticated:
            data = Bloger_data.objects.get(pk=id)
            post_data = Form_Bloger_data(instance=data)
            return render(request,self.template_name,{'form':post_data,})
        else:
            return HttpResponseRedirect('/login/user')
    def post(self,request,id):
        if request.user.is_authenticated:
            if request.method =='POST':
                data = Bloger_data.objects.get(pk=id)
                post_data = Form_Bloger_data(request.POST,instance=data)
                if post_data.is_valid():
                    post_data.save()
                    messages.success(request,'Successfully Your Post Updated.')
            return render(request,self.template_name,{'form':post_data})
        else:
            return HttpResponseRedirect('/login/user')
class Update_image(View):
    template_name = 'blogs/index.html'
    def get(self,request,id):
        if request.user.is_authenticated:
            data1 = Model_Image.objects.get(pk=id)
            post_data = ImageForm(instance=data1)
            return render(request,self.template_name,{'form':post_data,})
        else:
            return HttpResponseRedirect('/login/user')
    def post(self,request,id):
        if request.user.is_authenticated:
            if request.method =='POST':
                data1 = Model_Image.objects.get(pk=id)
                post_data = ImageForm(request.POST,instance=data1)
                if post_data.is_valid():
                    post_data.save()
                    messages.success(request,'Successfully Your Post Updated.')
            return render(request,self.template_name,{'form':post_data})
        else:
            return HttpResponseRedirect('/login/user')
class Delete_Post(View):
    def get(self,request,id):
        if request.user.is_authenticated:
            data = Bloger_data.objects.get(pk=id)
            data.delete()
            messages.success(request,'Successfully Your Post Deleted.')
            return HttpResponseRedirect('/board/desh')
        else:
            return HttpResponseRedirect('/login/user')
    def post(self,request,id):
        if request.user.is_authenticated:
            data = Bloger_data.objects.get(pk=id)
            data.delete()
            messages.success(request,'Successfully Your Post Deleted.')
            return HttpResponseRedirect('/board/desh')
        else:
            return HttpResponseRedirect('/login/user')
class Delete_image(View):
    def get(self,request,id):
        if request.user.is_authenticated:
            data1 = Model_Image.objects.get(pk=id)
            data1.delete()
            messages.success(request,'Successfully Your Post Deleted.')
            return HttpResponseRedirect('/board/desh')
        else:
            return HttpResponseRedirect('/login/user')
    def post(self,request,id):
        if request.user.is_authenticated:
            data1 = Model_Image.objects.get(pk=id)
            data1.delete()
            messages.success(request,'Successfully Your Post Deleted.')
            return HttpResponseRedirect('/board/desh')
        else:
            return HttpResponseRedirect('/login/user')
class Delete_Video(View):
    def get(self,request,id):
        if request.user.is_authenticated:
            data1 = ModelUpVideo.objects.get(pk=id)
            data1.delete()
            messages.success(request,'Successfully Your Post Deleted.')
            return HttpResponseRedirect('/board/desh')
        else:
            return HttpResponseRedirect('/login/user')
    def post(self,request,id):
        if request.user.is_authenticated:
            data1 = ModelUpVideo.objects.get(pk=id)
            data1.delete()
            messages.success(request,'Successfully Your Post Deleted.')
            return HttpResponseRedirect('/board/desh')
        else:
            return HttpResponseRedirect('/login/user')
class Delete_Chat(View):
    def get(self,request,id):
        if request.user.is_authenticated:
            data1 = DATA_chat.objects.get(pk=id)
            data1.delete()
            messages.success(request,'Successfully Your Post Deleted.')
            return HttpResponseRedirect('/chat/chat')
        else:
            return HttpResponseRedirect('/login/user')
    def post(self,request,id):
        if request.user.is_authenticated:
            data1 = DATA_chat.objects.get(pk=id)
            data1.delete()
            messages.success(request,'Successfully Your Post Deleted.')
            return HttpResponseRedirect('/chat/chat')
        else:
            return HttpResponseRedirect('/login/user')
def user_logout(request):
    logout(request)
    return HttpResponseRedirect('/login/user')

def image_upload_view(request):
    if request.user.is_authenticated:
        """Process images uploaded by users"""
        if request.method == 'POST':
            form = ImageForm(request.POST, request.FILES)
            if form.is_valid():
                user = request.user
                title=form.cleaned_data['title']
                img=form.cleaned_data['image']
                reg=Model_Image(user=user,title=title,image=img)
                reg.save()
                # Get the current instance object to display in the template
                img_obj = form.instance
                return render(request, 'blogs/index.html', {'form': form, 'img_obj': img_obj})
        else:
            form = ImageForm()
        return render(request, 'blogs/index.html', {'form': form})
    else:
        return HttpResponseRedirect('/login/user')
def profilephotoset(request):
    if request.user.is_authenticated:
        """Process images uploaded by users"""
        if request.method == 'POST':
            form = Userprofileform(request.POST, request.FILES)
            if form.is_valid():
                user = request.user
                # user=form.cleaned_data['user']
                title=form.cleaned_data['bio']
                img=form.cleaned_data['pro_image']
                reg=UserProfile(user=user,bio=title,pro_image=img)
                reg.save()
                # Get the current instance object to display in the template
                img_obj = form.instance
                return render(request, 'blogs/index.html', {'form': form, 'img_obj': img_obj})
        else:
            form = Userprofileform()
        return render(request, 'blogs/index.html', {'form': form})
    else:
        return HttpResponseRedirect('/login/user')
def alldata(request):
    if request.user.is_authenticated:
        videos =ModelUpVideo.objects.order_by('?')
        return render(request,'blogs/show.html',{'data':videos})
    else:
        return HttpResponseRedirect('/login/user')
def galery(request):
    if request.user.is_authenticated:
        data =Model_Image.objects.order_by('?')
        return render(request,'blogs/galery.html',{'show':data})
    else:
        return HttpResponseRedirect('/login/user')
def showvideo(request): 
    if request.user.is_authenticated:
        lastvideo= ModelUpVideo.objects.order_by('?')
        form= VideoForm(request.POST or None, request.FILES or None)
        if form.is_valid():
            user = request.user
            title=form.cleaned_data['name']
            video=form.cleaned_data['videofile']
            reg=ModelUpVideo(user=user,name=title,videofile=video)
            reg.save()
            messages.success(request,'Successfully Your video uploded.')
        context= {'videofile': lastvideo,
                'form': form
                }  
        return render(request, 'blogs/video.html', context)
    else:
        return HttpResponseRedirect('/login/user')

@login_required
def profile(request):
    if request.user.is_authenticated:
    # user=User.objects.all()
    # print(user)
        username = request.user
        userdata = UserPersionalData.objects.filter(user= username )
        print(username)
        post_data = UserProfile.objects.filter(user= username )
        return render(request, 'blogs/user_profile.html', {"user":username,'img':post_data,'post1':userdata})
    else:
        return HttpResponseRedirect('/login/user')    


def formchat(request):
    if request.user.is_authenticated:
        if request.method =='POST':
            fm = Chat_form(request.POST)
            self_user = None
            if fm.is_valid():
                #user = request.POST['user']
                userlist =[]
                instance = User.objects.values_list('username',flat=True)
                for i in instance:
                        userlist.append(i)
                usernam = request.POST['username']
                if usernam in userlist:
                    s=usernam
                else:
                    print('no')
                print(s)  
                self_user  =  fm.save() 
        else:
            fm=Chat_form()
            instance = User.objects.values_list('username',flat=True)
            user = request.user
            
            post_data = DATA_chat.objects.filter(user= user )
            return render(request,'blogs/chatdata.html',{'form':fm,'data':post_data,"userdata":instance})
        user = request.user
        if self_user:
            my_obj = DATA_chat.objects.get(id=self_user.id)
            my_obj.user.add(User.objects.get(username=request.user))
            messages.success(request,'Successfully Your send to the Message.')
        instance = User.objects.values_list('username',flat=True)
        post_data = DATA_chat.objects.filter(user= user )
        return render(request,'blogs/chatdata.html',{'form':fm,'data':post_data,"userdata":instance})
    else:
        return HttpResponseRedirect('/login/user')    

def Userinformation(request):
    if request.user.is_authenticated:
        if request.method =='POST':
            fm = Usercontectform(request.POST)
            if fm.is_valid():
                user = request.user
                # user=fm.cleaned_data['user']
                m_no=fm.cleaned_data['mobailno']
                WEB=fm.cleaned_data['website']
                gender=fm.cleaned_data['gender']
                dob=fm.cleaned_data['dob']
                reg=UserPersionalData(user=user,mobailno=m_no,website=WEB,gender=gender,dob=dob)
                reg.save()
                messages.success(request,'Successfully Your add to the persional details.')
                fm = Usercontectform()
        else:
            fm = Usercontectform()
            return render(request,'blogs/useradditionaldetails.html',{'form':fm})
        return render(request,'blogs/useradditionaldetails.html',{'form':fm})
    else:
        return HttpResponseRedirect('/login/user')    
           
# def re_profile(request):
#     return render(request,'registration/profile.html')


# def PasswordReset(request):
#     if request.method == 'POST':
#         fm=PasswordResetForm(request.POST)
#         if fm.is_valid():
#             fm.save()
#     else:
#         fm=PasswordResetForm()
#         return render(request,'registration/resetpass.html',{'reset':fm})
#     return render(request,'registration/resetpass.html',{'reset':fm})
