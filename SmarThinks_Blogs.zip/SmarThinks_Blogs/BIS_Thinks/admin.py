from django.contrib import admin
from . models import Bloger_data,Model_Image,ModelUpVideo,DATA_chat
from profileapp.models import UserProfile,UserPersionalData
# Register your models here.
@admin.register(Bloger_data)
class BAGIRAAdmin(admin.ModelAdmin):
    list_display = ['user','title','desc']


@admin.register(Model_Image)
class imageAdmin(admin.ModelAdmin):
    list_display = ['user','title','image']

@admin.register(ModelUpVideo)
class upvideoAdmin(admin.ModelAdmin):
    list_display = ['user','name','videofile']

@admin.register(DATA_chat)
class ModelChatAdmin(admin.ModelAdmin):
    list_display = ['id','message','images','video','get_parents']


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ['user','bio','pro_image']


@admin.register(UserPersionalData)
class UserPersionalDataAdmin(admin.ModelAdmin):
    list_display = ['user','mobailno','website','gender','dob']
