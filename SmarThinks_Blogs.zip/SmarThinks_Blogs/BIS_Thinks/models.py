from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class Bloger_data(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    desc = models.TextField(max_length=4000)


class Model_Image(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    image = models.ImageField(upload_to='images')

    def __str__(self):
        return self.title

class ModelUpVideo(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    name= models.CharField(max_length=500)
    videofile= models.FileField(upload_to='videos/', null=True, verbose_name="")

    def __str__(self):
        return self.name + ": " + str(self.videofile)


class DATA_chat(models.Model):
    user = models.ManyToManyField(User)
    message = models.CharField(max_length=400)
    images = models.ImageField(upload_to='images',default='not available')
    video= models.FileField(upload_to='videos/',default='not available')

    def get_parents(self):
            return ",".join([str(p) for p in self.user.all()])
    def __unicode__(self):
        return "{0}".format(self.message)