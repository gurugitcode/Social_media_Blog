from django.apps import AppConfig


class BisThinksConfig(AppConfig):
    name = 'BIS_Thinks'
