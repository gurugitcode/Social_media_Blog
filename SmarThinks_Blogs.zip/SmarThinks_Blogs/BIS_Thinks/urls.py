from django.urls import path
from . import views
urlpatterns = [
    path('home',views.HomePage.as_view(),name='home'),
    path('profilepage',views.ProfilePage,name='profilepage'),
    path('create',views.User_Create.as_view(),name='usercrate'),
    path('user',views.UserLogin,name='userlogin'),
    path('logout',views.user_logout,name='userlogout'),
    path('post',views.Add_Post.as_view(),name='addpost'),
    path('desh',views.DeshBoard.as_view(),name='DeshBoard'),
    path('uplode',views.image_upload_view,name='imageuplode'),
    path('show',views.alldata,name='show'),
    path('galery',views.galery,name='galery'),
    path('videoshow',views.showvideo,name='videoshow'),
    path('updateimg<int:id>/',views.Update_image.as_view(),name='Update_Image'),
    path('update<int:id>/',views.Update_post.as_view(),name='Update_post'),
    path('<int:id>/',views.Delete_Post.as_view(),name='Delete_Post'),
    path('img<int:id>/',views.Delete_image.as_view(),name='Delete_image'),
    path('video<int:id>/',views.Delete_Video.as_view(),name='Delete_video'),
    path('chat<int:id>/',views.Delete_Chat.as_view(),name='Delete_chat'),
    path('profilepage/',views.profile,name='pro_page'),
    path('chat/',views.formchat,name='formchat'),
    path('PHOTO/',views.profilephotoset,name='profilephotoset'),
    path('p_details/',views.Userinformation,name='Usetion'),

    
]
