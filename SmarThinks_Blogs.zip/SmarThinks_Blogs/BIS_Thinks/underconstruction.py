from django.shortcuts import render, HttpResponse
from django.template.response import TemplateResponse 
from profileapp.models import  UserPersionalData,UserProfile
from django.contrib.auth.models import User, Group
class UnderConstructionsMiddleware:
    def __init__(self,get_response):
        self.get_response = get_response
        print('this site is -----')
    def __call__(self,request):
        print('this site is under construction')
        # name = request.user
        # post_data = UserProfile.objects.filter(user= name )
        # request.session['name']=str(post_data)
        response = render(request,'blogs/uc.html')
        # response = self.get_response(request)
        return response
    
    # def process_view(request, *args, **kwargs):
    #     print('This is process view ----- Before view')
    #     return None
