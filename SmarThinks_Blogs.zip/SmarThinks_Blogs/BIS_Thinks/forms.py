from django import forms
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm,UsernameField,UserChangeForm
from django.contrib.auth.models import User
from .models import Bloger_data,Model_Image,ModelUpVideo,DATA_chat
from profileapp.models import UserPersionalData,UserProfile

class  SignUpForm(UserCreationForm):
        password1=forms.CharField(label='Password',widget=forms.PasswordInput(attrs={'class':'form-control'}))
        password2 = forms.CharField(label='Conform Password',widget=forms.PasswordInput(attrs={'class':'form-control'}))
        class Meta:
            model = User
            fields = ['username','first_name','last_name','email']
            labels={'username':'UserNmae','firstname':'FirstName','lastname':'LastName','email':'Email'}
            widgets = {'username':forms.TextInput(attrs={'class':'form-control'}),
            'first_name':forms.TextInput(attrs={'class':'form-control'}),
            'last_name':forms.TextInput(attrs={'class':'form-control'}),
            'email':forms.EmailInput(attrs={'class':'form-control'})
            }


class LoginForm(AuthenticationForm):
    username = UsernameField(widget = forms.TextInput(attrs={'autofocus':True,'class':'form-control'}))
    password=forms.CharField(label='Password',strip=False,widget=forms.PasswordInput(attrs={'autocomplete':'current-password','class':'form-control'}))

class Form_Bloger_data(forms.ModelForm):
    class Meta:
        model = Bloger_data
        fields =['title','desc']
        labels = {'title':'Title','desc':'Description'}
        widgets = {'title':forms.TextInput(attrs={'class':'form-control'}),
        'desc':forms.Textarea(attrs={'class':'form-control'}), }


class ImageForm(forms.ModelForm):
    """Form for the image model"""
    class Meta:
        model = Model_Image
        fields = ('title', 'image')
        labels = {'title':'Title','image':'UplodePhoto'}
        widgets = {'title':forms.TextInput(attrs={'class':'form-control'}),
        'image':forms.FileInput(attrs={'class':'form-control'}), }



class VideoForm(forms.ModelForm):
    class Meta:
        model= ModelUpVideo
        fields= ["name", "videofile"]
        labels = {'name':'Title','videofile':'UplodeVideo'}
        widgets = {'name':forms.TextInput(attrs={'class':'form-control'}),
        'videofile':forms.FileInput(attrs={'class':'form-control'}), }

       
class EditUserProfileForm(UserChangeForm):
    password =None
    class Meta:
        model = User
        fields = ['username','first_name','last_name','email','date_joined','last_login','is_active']
        labels = {'email':'Email'}


class Chat_form(forms.ModelForm):
    class Meta:
        # exclude = ('created_by',)
        model= DATA_chat
        fields= ['user','message','images','video']
        labels = {'Users':'user','Message':'message','Photo':'images','Video':'video',}
        widgets = {'user':forms.SelectMultiple(attrs={'class':'form-control'}),
        'message':forms.TimeInput(attrs={'class':'form-control'}),
        'image':forms.FileInput(attrs={'class':'form-control'}), 
        'videofile':forms.FileInput(attrs={'class':'form-control'}),
        
        }
    
      

     
class Userprofileform(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['bio','pro_image']
        widgets = {'bio':forms.TextInput(attrs={'class':'form-control'}),
        'pro_image':forms.FileInput(attrs={'class':'form-control'}), }
        
 
class Usercontectform(forms.ModelForm):
    class Meta:
        model = UserPersionalData
        fields = ['mobailno','website','gender','dob']
        widgets = {'mobailno':forms.NumberInput(attrs={'class':'form-control'}),
        'website':forms.TextInput(attrs={'class':'form-control'}),
        'gender':forms.TextInput(attrs={'class':'form-control'}),
        'dob':forms.DateTimeInput(attrs={
            'class': 'form-control datepicker-input',
            'data-target': '#datepicker1'
        }) }
        
